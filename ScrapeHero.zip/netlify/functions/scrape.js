const fetch = require('node-fetch');
const { JSDOM } = require('jsdom');

exports.handler = async function(event) {
  const url = new URLSearchParams(event.queryStringParameters).get("url");
  if (!url) return { statusCode: 400, body: "Missing URL" };

  try {
    const res = await fetch(url);
    const html = await res.text();
    const dom = new JSDOM(html);
    const cleanText = dom.window.document.body.textContent.replace(/\s+/g, ' ').trim();
    return { statusCode: 200, body: cleanText };
  } catch (e) {
    return { statusCode: 500, body: "Failed to fetch" };
  }
};

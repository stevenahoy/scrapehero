chrome.runtime.onInstalled.addListener(() => {
  console.log("ScrapeHero installed");
});
